package Ej22;

public interface Transporte {
	public void incluirPaquete(Paquete paquete);

	public float pesoTotal();

	public int recorrerDistancia();

}
